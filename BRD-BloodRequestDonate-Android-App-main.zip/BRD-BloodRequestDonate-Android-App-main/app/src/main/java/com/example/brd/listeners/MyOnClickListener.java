package com.example.brd.listeners;

public interface MyOnClickListener {
    void getPosition(int position);
}
